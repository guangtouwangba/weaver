create function update_conversation_stats() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE conversations
    SET 
        message_count = message_count + 1,
        last_message_at = NEW.created_at,
        updated_at = NOW()
    WHERE id = NEW.conversation_id;
    RETURN NEW;
END;
$$;

alter function update_conversation_stats() owner to postgres;

